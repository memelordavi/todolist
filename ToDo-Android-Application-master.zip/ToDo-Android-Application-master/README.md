# ToDo-Android-Application
A simple ToDo Android Application using RecyclerView



Screenshots:


![image](https://user-images.githubusercontent.com/17126310/57970403-8edaac00-799e-11e9-9efc-ef75bb5a8b48.png) ![image](https://user-images.githubusercontent.com/17126310/57970414-b03b9800-799e-11e9-9206-94324d7d7565.png)

![image](https://user-images.githubusercontent.com/17126310/57970530-c007ac00-799f-11e9-8182-8e7ceba6af70.png) ![image](https://user-images.githubusercontent.com/17126310/57970533-d4e43f80-799f-11e9-86ab-d5710309a639.png)

![image](https://user-images.githubusercontent.com/17126310/57970539-eaf20000-799f-11e9-985b-4c5ff8446dea.png) ![image](https://user-images.githubusercontent.com/17126310/57970541-f2b1a480-799f-11e9-8052-39802259b03d.png)

![image](https://user-images.githubusercontent.com/17126310/57970543-02c98400-79a0-11e9-90d2-cd19cd1fdae5.png) ![image](https://user-images.githubusercontent.com/17126310/57970548-0c52ec00-79a0-11e9-8e69-2788f9e8fc41.png)

![image](https://user-images.githubusercontent.com/17126310/57970552-1a087180-79a0-11e9-9c9b-c32bd8efe8ab.png)


